package com.example.atwork;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;

import java.util.List;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    private static final String TAG = "GeofenceBroadcastReceiver";
    private static final String ACTION_PROCESS_GEOFENCE_EVENT = "com.example.atwork.ACTION_PROCESS_GEOFENCE_EVENT";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "Intent action: " + intent.getAction());
        if (!ACTION_PROCESS_GEOFENCE_EVENT.equals(intent.getAction())) {
            Log.e(TAG, "Unexpected intent action: " + intent.getAction());
            return;
        }

        Toast.makeText(context, "Geofence triggered", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "GeofenceBroadcastReceiver triggered");

        NotificationHelper notificationHelper = new NotificationHelper(context);

        GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);
        if (geofencingEvent == null) {
            Log.e(TAG, "GeofencingEvent is null");
            return;
        }

        if (geofencingEvent.hasError()) {
            Log.e(TAG, "GeofencingEvent error: " + geofencingEvent.getErrorCode());
            return;
        }

        List<Geofence> geofenceList = geofencingEvent.getTriggeringGeofences();
        if (geofenceList == null || geofenceList.isEmpty()) {
            Log.e(TAG, "No triggering geofences found");
            return;
        }

        for (Geofence geofence : geofenceList) {
            Log.d(TAG, "Triggered Geofence ID: " + geofence.getRequestId());
        }

        int transitionType = geofencingEvent.getGeofenceTransition();
        switch (transitionType) {
            case Geofence.GEOFENCE_TRANSITION_ENTER:
                Toast.makeText(context, "Marked IN", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Entering geofence");
                notificationHelper.sendHighPriorityNotification("Marked IN", "You have entered the geofence area", MapsActivity.class);
                break;
            case Geofence.GEOFENCE_TRANSITION_EXIT:
                Toast.makeText(context, "Marked out", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Exiting geofence");
                notificationHelper.sendHighPriorityNotification("Marked out", "You have exited the geofence area", MapsActivity.class);
                break;
            default:
                Log.e(TAG, "Unknown geofence transition type: " + transitionType);
                break;
        }
    }
}